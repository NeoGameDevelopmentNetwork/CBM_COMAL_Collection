##########################################################
#          UNICOMAL V3.11  STANDARD & DEVELOPER VERSION  #
##########################################################
#          DOS & OS2 VERSION INCLUDED                    #
##########################################################
#          COMPILER FOR DOS AND OS2                      #
##########################################################


To change setup (keyboard etc.) run INSTALL.EXE in comal
folder.

Incuded in this archive is dosbox 0.74-3

For the best experience run this software in 32bit
operating systems. Works great with Oracle virtual box.

This old software surfaced with the help from:

Scenelist.org

